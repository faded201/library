# Xavier OS

Run API:
uvicorn backend:app --reload

Run UI:
streamlit run frontend_streamlit.py

Docker:
docker compose up --build
